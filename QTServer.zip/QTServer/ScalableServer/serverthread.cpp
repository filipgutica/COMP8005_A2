#include "serverthread.h"

ServerThread::ServerThread(qintptr sd, QObject *parent) : QThread(parent),_socketDescriptor(sd)
{
    _mainWindow = (MainWindow*) parent;
}

void ServerThread::run()
{
    _tcpSocket = new QTcpSocket();

    qDebug () << "Setting socket descriptor " << _socketDescriptor;

    if (!_tcpSocket->setSocketDescriptor(_socketDescriptor))
    {
        qDebug() << "Cant set socket descriptor " << _socketDescriptor <<  " " << _tcpSocket->errorString();
        return;
    }

    connect(_tcpSocket, SIGNAL(readyRead()), this, SLOT(readSocket()), Qt::DirectConnection);
    connect(_tcpSocket, SIGNAL(disconnected()), this, SLOT(handleSocketDisconnect()), Qt::DirectConnection);

    exec();
}

void ServerThread::readSocket()
{
    QByteArray data = _tcpSocket->readAll();

    QString strInfo = QString("%1").arg(*data);

    qDebug() << "Received: " << strInfo;

    _tcpSocket->write(data);
}

void ServerThread::handleSocketDisconnect()
{
    _tcpSocket->close();
    _tcpSocket->deleteLater();

    qDebug() << "CLient Disconnect" ;

    _mainWindow->clientDisconnected();

    this->exit();
    this->deleteLater();
}
